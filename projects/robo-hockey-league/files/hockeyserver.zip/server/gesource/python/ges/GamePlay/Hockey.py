################ Copyright 2005-2016 Team GoldenEye: Source #################
#
# This file is part of GoldenEye: Source's Python Library.
#
# GoldenEye: Source's Python Library is free software: you can redistribute 
# it and/or modify it under the terms of the GNU General Public License as 
# published by the Free Software Foundation, either version 3 of the License, 
# or(at your option) any later version.
#
# GoldenEye: Source's Python Library is distributed in the hope that it will 
# be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General 
# Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with GoldenEye: Source's Python Library.
# If not, see <http://www.gnu.org/licenses/>.
#############################################################################
from GamePlay import GEScenario
from .Utils import GetPlayers
from .Utils.GEWarmUp import GEWarmUp
import GEPlayer, GEUtil, GEMPGameRules as GERules, GEGlobal as Glb

USING_API = Glb.API_VERSION_1_2_0


def SafePlayerName( player ):
    try:
        return player.GetPlayerName()
    except UnicodeDecodeError:
        return "Someone"

class Penalty:
    def __init__( self, player, time ):
        self._player = player
        self._time = time
        self.lastDisplayedCountdown = -1

    def GetPlayer( self ):
        return self._player

    def GetTime( self ):
        return self._time

class PenaltyManager:
    def __init__( self ):
        self.penalties = []

    def Clear( self ):
        for penalty in self.penalties:
            penalty.GetPlayer().SetTargetName("")

        self.penalties.clear()

    def EnsurePlayerTargetName( self, player ):
        if not player:
            return
        # make sure this player is actually penalized
        for penalty in self.penalties:
            if penalty.GetPlayer() == player:
                # set the correct team penalty
                if player.GetTeamNumber() == Glb.TEAM_MI6:
                    player.SetTargetName("penalty_mi6")
                else:
                    player.SetTargetName("penalty_janus")

                return

        # player should not be penalized
        player.SetTargetName("")


    def AddPlayer( self, player):

        if not player:
            return

        penalty_enabled = int( GEUtil.GetCVarValue( "hockey_penalty_enabled" ) )
        penalty_timeout = int( GEUtil.GetCVarValue( "hockey_penalty_timeout" ) )
        penalty_supported = int( GEUtil.GetCVarValue( "hockey_penalty_map_supported" ) )

        # make sure penalties are enabled
        if penalty_enabled == 0 \
        or penalty_supported == 0:
            return False

        # make sure this player is not already penalized
        for penalty in self.penalties:
            if penalty.GetPlayer() == player:
                return False

        # penalize the player
        if player.GetTeamNumber() == Glb.TEAM_MI6:
            player.SetTargetName("penalty_mi6")
        else:
            player.SetTargetName("penalty_janus")

        penalty = Penalty(player, GEUtil.GetTime() + penalty_timeout)
        self.penalties.append(penalty)

        self.DisplayCountdown( penalty )

        # inform of penalty in chat
        if player.GetTeamNumber() == Glb.TEAM_MI6:
            GEUtil.ClientPrint( None, Glb.HUD_PRINTTALK, "^i" + SafePlayerName(player) + "^w has received a penalty." )
        else:
            GEUtil.ClientPrint( None, Glb.HUD_PRINTTALK, "^r" + SafePlayerName(player) + "^w has received a penalty." )

    def RemovePlayer( self, player ):
        if not player:
            return

        for penalty in self.penalties:
            if penalty.GetPlayer() == player:
                # remove penalty from player
                player.SetTargetName("")
                self.penalties.remove(penalty)

    def Update( self ):
        current_time = GEUtil.GetTime()
        for penalty in self.penalties:
            self.DisplayCountdown( penalty )
            if current_time > penalty.GetTime():
                # penalty expired for player
                penalty.GetPlayer().SetTargetName("")
                self.penalties.remove(penalty)

    def DisplayCountdown( self, penalty ):
        countdown = int(penalty.GetTime() - GEUtil.GetTime()) + 1

        if countdown < 1 \
        or penalty.lastDisplayedCountdown == countdown \
        or not penalty.GetPlayer():
            return

        penalty.lastDisplayedCountdown = countdown

        GEUtil.HudMessage( penalty.GetPlayer(), "Penalty!", -1, Hockey.MSG_ABOVE_MID_YPOS, Hockey.COLOR_NEGATIVE, 1, Hockey.MSG_PENALTY_TITLE_CHANNEL )
        GEUtil.HudMessage( penalty.GetPlayer(), str(countdown), -1, Hockey.MSG_MID_YPOS, Hockey.COLOR_NEGATIVE, 1, Hockey.MSG_PENALTY_COUNTDOWN_CHANNEL )



# Deathmatch uses all the default behavior defined in GamePlay\__init__.py
# so the only thing we need to define here is the text entries it uses.
class Hockey( GEScenario ):
    ( MSG_GOAL_CHANNEL, MSG_PENALTY_TITLE_CHANNEL, MSG_PENALTY_COUNTDOWN_CHANNEL, MSG_PENALTY_ANNOUNCE_CHANNEL ) = range( 4 )
    
    COLOR_MI6 = GEUtil.Color( 94, 171, 231, 255 )
    COLOR_JANUS = GEUtil.Color( 206, 43, 43, 255 )
    COLOR_POSITIVE = GEUtil.Color( 50, 255, 50, 255 )
    COLOR_NEGATIVE = GEUtil.Color( 255, 50, 50, 255 )

    MSG_MISC_YPOS = 0.25
    MSG_ABOVE_MID_YPOS = 0.45
    MSG_MID_YPOS = 0.5
    MSG_BOTTOM_YPOS = 0.7

    def __init__( self ):
        GEScenario.__init__( self )

        self.mi6_score = 0
        self.janus_score = 0

        self.in_overtime = False
        self.in_round = False

        self.penaltyManager = PenaltyManager()

        self.WaitingForPlayers = True
        self.notice_WaitingForPlayers = 0
        self.warmupTimer = GEWarmUp( self )

    def GetPrintName( self ):
        return "Hockey"

    def GetScenarioHelp( self, help_obj ):
        help_obj.SetDescription( "Try to get the puck into the enemy team's goal!\n\nHit the puck: aim low and slash your knife\n\nSlapshot the puck: aim for the right or left side and slash\n\nLob the puck: crouch, aim up, and slash\n\nDon't just chase the puck, keep your team spread out." )

    def GetGameDescription( self ):
        return "Hockey"

    def GetTeamPlay( self ):
        return Glb.TEAMPLAY_ALWAYS

    def CalculateCustomDamage( self, victim, info, health, armour ):

        if victim == None:
            return health, armour
        
        if info.GetDamage() <= 10:
            if info.GetAttacker() != None \
            and info.GetAttacker().GetTargetName() == "cart_z01" \
            and victim.GetTargetName() == "driver_z01":
                return 0, 0

            if info.GetAttacker() != None \
            and info.GetAttacker().GetTargetName() == "cart_z02" \
            and victim.GetTargetName() == "driver_z02":
                return 0, 0

        if info.GetAttacker() != None \
        and info.GetAttacker().GetClassname() == "player" \
        and victim.GetClassname() == "player":
        
            if not self.WaitingForPlayers \
            and not self.warmupTimer.IsInWarmup():
                self.penaltyManager.AddPlayer(info.GetAttacker())

            return 0, 0

        return health, armour

    def OnLoadGamePlay( self ):
        self.CreateCVar( "hockey_mi6_scored", "0", "MI6 scored boolean, set by map (Do not set directly)" )
        self.CreateCVar( "hockey_janus_scored", "0", "Janus scored boolean, set by map (Do not set directly)" )

        self.CreateCVar( "hockey_penalty_enabled", "1", "Enable/disable penalties." )
        self.CreateCVar( "hockey_penalty_timeout", "10", "The amount of time in seconds to keep someone in the penalty box." )
        self.CreateCVar( "hockey_penalty_map_supported", "0", "Map supports penalties boolean, set by map (Do not set directly)" )
        self.CreateCVar( "hockey_warmuptime", "15", "The warmup time in seconds. (Use 0 to disable)" )

        GERules.SetAllowTeamSpawns( False )

    def OnUnloadGamePlay(self):
        super( Hockey, self ).OnUnloadGamePlay()
        self.warmupTimer = None

    def OnCVarChanged( self, name, oldvalue, newvalue ):
        if name == "hockey_warmuptime":
            if self.warmupTimer.IsInWarmup():
                val = int( newvalue )
                self.warmupTimer.StartWarmup( val )
                if val <= 0:
                    GERules.EndRound( False )

        goal_scored = False
        if not self.WaitingForPlayers and not self.warmupTimer.IsInWarmup() and self.in_round:
            if name == "hockey_mi6_scored" \
            and newvalue == "1" and oldvalue == "0":
                goal_scored = True
                self.mi6_score = self.mi6_score + 1
                GERules.GetTeam( Glb.TEAM_MI6 ).SetRoundScore(self.mi6_score)
                GEUtil.HudMessage( Glb.TEAM_JANUS, "The enemy team scored a goal!", -1, self.MSG_MISC_YPOS, self.COLOR_NEGATIVE, 4.0, self.MSG_GOAL_CHANNEL )
                GEUtil.HudMessage( Glb.TEAM_MI6, "Your team scored a goal!", -1, self.MSG_MISC_YPOS, self.COLOR_POSITIVE, 4.0, self.MSG_GOAL_CHANNEL )
                GEUtil.EmitGameplayEvent( "mi6_scored" )

            elif name == "hockey_janus_scored" \
            and newvalue == "1" and oldvalue == "0":
                goal_scored = True
                self.janus_score = self.janus_score + 1
                GERules.GetTeam( Glb.TEAM_JANUS ).SetRoundScore(self.janus_score)
                GEUtil.HudMessage( Glb.TEAM_JANUS, "Your team scored a goal!", -1, self.MSG_MISC_YPOS, self.COLOR_POSITIVE, 4.0, self.MSG_GOAL_CHANNEL )
                GEUtil.HudMessage( Glb.TEAM_MI6, "The enemy team scored a goal!", -1, self.MSG_MISC_YPOS, self.COLOR_NEGATIVE, 4.0, self.MSG_GOAL_CHANNEL )
                GEUtil.EmitGameplayEvent( "janus_scored" )

        if goal_scored:
            # reset penalties
            self.penaltyManager.Clear()

            # reset health
            for player in GetPlayers():
                if player and not player.IsDead() and not player.IsObserver():
                    player.SetHealth(player.GetMaxHealth())


    def OnPlayerSpawn( self, player ):
        if not player:
            return

        self.penaltyManager.EnsurePlayerTargetName( player )

        # force the player to respawn until they are on the correct side of the field
        # terrible, terrible hack
        location = player.GetAbsOrigin()
        if player.GetTeamNumber() == Glb.TEAM_JANUS:
            if location.__getitem__(1) < 0:
                player.ForceRespawn()

        if player.GetTeamNumber() == Glb.TEAM_MI6:
            if location.__getitem__(1) > 0:
                player.ForceRespawn()

        if player.IsInitialSpawn():
            GEUtil.PopupMessage( player, "Hockey", "Work with your team to get the puck into the enemy goal!\n\nHit '%cl_ge_gameplay_help%' for basic tips." )

    def OnPlayerKilled( self, victim, killer, weapon ):
        GERules.GetTeam( Glb.TEAM_MI6 ).SetRoundScore(self.mi6_score)
        GERules.GetTeam( Glb.TEAM_JANUS ).SetRoundScore(self.janus_score)

        if not victim:
            return

        victim.StripAllWeapons() # Victim always loses their weapons so they never drop anything, as there are no weapon pickups in this mode.

    def OnPlayerConnect( self, player ):
        self.penaltyManager.RemovePlayer( player )

    def OnPlayerDisconnect( self, player ):
        self.penaltyManager.RemovePlayer( player )

    def OnRoundBegin(self):
        self.in_round = True
        self.mi6_score = 0
        self.janus_score = 0

        self.in_overtime = False

        self.penaltyManager.Clear()

        GERules.DisableWeaponSpawns()
        GERules.DisableAmmoSpawns()

    def OnRoundEnd(self):
        self.in_round = False

    def CanRoundEnd( self ):

        # No overtime with only 1 player.
        if GERules.GetNumActivePlayers() < 2:
            return True

        if GERules.IsIntermission():
            return False

        # Overtime if scores match
        if self.mi6_score == self.janus_score:
            if not self.in_overtime:
                self.in_overtime = True
                GEUtil.PopupMessage( None, "#GES_GPH_OVERTIME_TITLE", "#GES_GPH_OVERTIME" )

            return False

        return True

    def OnPlayerSay( self, player, text ):
        assert isinstance( player, GEPlayer.CGEMPPlayer )
        if not player:
            return

        text = text.lower()

        if "stuck" in text:
            GEUtil.HudMessage( player, "Type !kill to get unstuck", -1, -1, GEUtil.Color( 255, 50, 50, 255 ), 6.0 )
        
        if text == "!kill":
            player.CommitSuicide(True, True)
            return True

    def CheckWarmup(self):
        #Check to see if we can get out of warmup
        if self.WaitingForPlayers:
            if GERules.GetNumActivePlayers() > 1:
                self.WaitingForPlayers = False
                self.notice_WaitingForPlayers = 0
                if not self.warmupTimer.HadWarmup():
                    self.warmupTimer.StartWarmup( int( GEUtil.GetCVarValue( "hockey_warmuptime" ) ), True )
                else:
                    GERules.EndRound( False )
            elif GEUtil.GetTime() > self.notice_WaitingForPlayers:
                GEUtil.HudMessage( None, "#GES_GP_WAITING", -1, self.MSG_BOTTOM_YPOS, GEUtil.Color( 255, 255, 255, 255 ), 2.5, 1 )
                self.notice_WaitingForPlayers = GEUtil.GetTime() + 12.5

    def OnThink(self):
        
        self.penaltyManager.Update()
        self.CheckWarmup()
