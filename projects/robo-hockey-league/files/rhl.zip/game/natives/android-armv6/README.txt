This folder contains deprecated plain native libraries for platform android-armv6, please use the native JAR files in the jar folder.
