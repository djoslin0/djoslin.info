#! /usr/bin/python3
import os

with open('template.html') as f:
    template = f.read()

container_spaces = "                "
img_spaces = "                    "
section_template = """
            <div class="container">
                <p>$[HEADER]</p>
                <div class="moves">
$[IMGS]
                </div>
            </div>
"""

def gen_section(header, moves, reverse):
    if len(header) == 0:
        return ''

    imgs = ''
    buf = ''

    first_move = True
    moves = sorted(moves, key=lambda x: x.count(' '))
    for move in moves:
        if not first_move:
            imgs += container_spaces + "</div>\n"
            imgs += container_spaces + "<br />\n"
            imgs += container_spaces + '<div class="moves">\n'

        move = move.replace(' +', ', PLUS,').strip()

        for m in move.split():
            m_altered = m.replace(',', '').strip()

            if reverse and m_altered == 'B':
                m_altered = 'F'
            elif reverse and m_altered == 'F':
                m_altered = 'B'

            m_fname = 'images/' + m_altered + '.png'
            if os.path.isfile(m_fname):
                if len(buf) > 0:
                    imgs += img_spaces + '<div class="txt">' + buf + '</div>'
                    buf = ''
                imgs += img_spaces + '<img src="' + m_fname + '" />\n'
            else:
                buf += m + ' '

            if len(buf) > 0:
                imgs += img_spaces + '<div class="txt">' + buf + '</div>'
                buf = ''

        first_move = False

    return section_template.replace('$[HEADER]', header).replace('$[IMGS]', imgs)

def gen_character(character_name, filename, reverse):
    header = ''
    moves = []
    containers = ''
    with open(filename) as f:
        for line in f:
            if line.startswith(' ') or line.startswith('\t'):
                move = line.strip()
                if move.endswith(')') and '%' in move:
                    move = move.rsplit('(', 1)[0]
                moves.append(move)
            else:
                containers += gen_section(header, moves, reverse)
                header = line.strip()
                moves = []
    containers += gen_section(header, moves, reverse)

    output_name = character_name + '.html'
    if reverse:
        output_name = character_name + '_reverse.html'

    with open(output_name, 'w') as f:
        f.write(template.replace('$[CHARACTER]', character_name).replace('$[CONTAINERS]', containers))


directory = 'moves'
for filename in os.listdir(directory):
    f = os.path.join(directory, filename)
    if os.path.isfile(f):
        character_name = filename.split('.')[0]
        gen_character(character_name, f, False)
        gen_character(character_name, f, True)