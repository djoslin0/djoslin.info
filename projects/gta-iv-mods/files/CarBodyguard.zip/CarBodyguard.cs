﻿using System;
using System.Drawing;
using System.Windows.Forms;
using GTA;
using System.Collections;

namespace TestScriptCS {

   public class CarPassenger
   {
       public Ped ped;
       public bool sitting;
       public bool combat;
       public int spot;
       public Vector3 offset;
       public Vector3 addioffset;
       public Vehicle vehicle;
   }

   // ### Spawns a guard when pressing insert
   public class CarBodyguard : Script {

       Group group;
       Model PedModel = "M_Y_BOUNCER_02";
       Vehicle curVeh = null;

       Random rnd = new Random();

       float speedChange = 0f;
       float oldSpeed = 0f;
       int actionWait = 0;
       int actionWait2 = 0;

       CarPassenger[] carSpot;       
       AnimationFlags animflags = AnimationFlags.Unknown01 | AnimationFlags.Unknown05;
       AnimationSet anset = new AnimationSet("amb@bnch_dnk_idl");

       public CarBodyguard()
       {
           Interval = 50;
           group = Player.Group;
           carSpot = new CarPassenger[4];
           actionWait = 0;
           actionWait2 = 0;

           for (int i = 0; i < 4; i++)
           {
               carSpot[i] = new CarPassenger();
               carSpot[i].addioffset = new Vector3(0, 0, 0);
           }

           carSpot[0].offset = new Vector3(0.5f, -2.2f, 0.5f);
           carSpot[1].offset = new Vector3(-0.5f, -2.2f, 0.5f);
           carSpot[2].offset = new Vector3(0.5f, 1.2f, 0.5f);
           carSpot[3].offset = new Vector3(-0.5f, 1.2f, 0.5f);

           this.KeyDown += new GTA.KeyEventHandler(this.CarBodyguard_KeyDown);
           this.Tick += new EventHandler(this.CarBodyguard_Tick);
      }

       private void detachPedSpot(CarPassenger tspot)
       {
           if (tspot == null) { return; }
           if (tspot.ped != null)
           {
               if (curVeh != null & tspot.ped.isAttachedToVehicle())
               {
                   tspot.ped.Detach();
                   tspot.ped.AttachTo(curVeh, tspot.offset + tspot.addioffset);
                   tspot.ped.Detach();
                   tspot.ped.Animation.Play(new AnimationSet("veh@boat_speed"), "get_out_ds ", 10.0f);
                   tspot.ped.Position += new Vector3(0f, 0f, 0.1f);
                   Vector3 nvel = tspot.offset + tspot.addioffset;
                   nvel /= 2f;
                   nvel.Normalize();
                   tspot.ped.Velocity = nvel;
                   tspot.ped.Task.ClearAllImmediately();
               }
               tspot.ped = null;
           }
       }

       private void standUp(CarPassenger tspot)
       {
           tspot.sitting = false;
           tspot.ped.Animation.Play(new AnimationSet("veh@boat_speed"), "get_out_ds ", 1.0f);
           tspot.ped.Detach();
           Vector3 addistand = new Vector3(0, 0, 0.85f);
           tspot.ped.AttachTo(curVeh, tspot.offset + tspot.addioffset + addistand);
           actionWait = rnd.Next(30);
       }

       private void sitDown(CarPassenger tspot)
       {
           tspot.sitting = true;
           tspot.ped.Animation.Play(new AnimationSet("amb@car_low_ps_loops"), "alt_sit_ps_a", 1.0f, animflags);
           tspot.ped.Detach();
           tspot.ped.AttachTo(curVeh, tspot.offset + tspot.addioffset);
           actionWait = rnd.Next(30);
       }


       private void PedIsAttached(CarPassenger tspot)
       {
           if (curVeh == null) { return; }
           if (actionWait2 > 0) { return; }

           // Abrupt speed change? Upside down? Detach.
           if (speedChange < -6 || curVeh.isUpsideDown) 
           { 
               actionWait2 = rnd.Next(6); Ped tmpped = tspot.ped; detachPedSpot(tspot); 
               tmpped.ForceRagdoll(200, false);
               tmpped.Velocity = curVeh.Velocity;

               return; 
           }

           if (actionWait > 0) { return; }

           if (tspot.vehicle != Player.Character.CurrentVehicle || tspot.vehicle == null) { detachPedSpot(tspot); return; }

           // The ped has been assigned, and is attached
           if (tspot.sitting)
           {
               // If we're not speeding, consider standing up and shooting
               if (curVeh.Speed < 12f)
               {
                   // He's sitting, but can't shoot while sitting. He also can't see enemies. Check to see if a team mate is shooting.
                   foreach (Ped tped in group)
                   {
                       if (tped.isInCombat)
                       {
                           // A teammate is in combat, the ped should stand up and shoot
                           standUp(tspot);
                           break;
                       }
                   }
               }
           }
           else
           {
               // He's standing, but should he be?
               if (curVeh.Speed > 14f)
               {
                   // We're speeding, sit down.
                   sitDown(tspot);
               }
               else
               {
                   bool combat = false;
                   foreach (Ped tped in group)
                   {
                       if (tped.isInCombat)
                       {
                           // Someone is still in combat, keep standing
                           combat = true;
                           break;
                       }
                   }

                   if (!combat)
                   {
                       // No one is in combat, sit back down.
                       sitDown(tspot);
                   }
               }
           }
       }

       private void PedIsntAttachedYet(CarPassenger tspot)
       {
           // The ped has been assigned, but he's not attached. Wait until he's close enough
           if (tspot.ped.Position.DistanceTo(curVeh.Position + tspot.offset + tspot.addioffset) < 1.5f + Math.Abs(tspot.offset.Z + tspot.addioffset.Z)*1f)
           {
               // Alright, he's close enough. Attach.
               tspot.ped.AttachTo(curVeh, tspot.offset + tspot.addioffset);

               // Sit
               tspot.ped.Animation.Play(new AnimationSet("amb@car_low_ps_loops"), "alt_sit_ps_a", 1.0f, animflags);
               tspot.sitting = true;
           }
       }

       private void SpotTick(CarPassenger tspot)
       {
           if (tspot.ped != null)
           {
               if (!tspot.ped.Exists() || !tspot.ped.isAliveAndWell)
               {
                   // Ped exists, but he doesn't really exist. Or he's dead. Detatch!
                   detachPedSpot(tspot);
               }
           }

           if (tspot.ped != null)
           {
               if (!tspot.ped.isAttachedToVehicle())
               {
                   // The ped has been assigned, but he's not attached. Wait until he's close enough
                   PedIsntAttachedYet(tspot);
               }
               else
               {
                   // The ped has been assigned, and is attached
                   PedIsAttached(tspot);
               }
           }

       }

       private void setAddiOffset(String carname)
       {
           foreach (CarPassenger tspot in carSpot)
           {
               tspot.addioffset = new Vector3(0, 0, 0);
           }

           switch (carname)
           {
               case "FAGGIO":
               case "HELLFURY":
               case "PCJ":
               case "BOBBER":
               case "NRG900":
               case "SANCHEZ":
               case "ZOMB":
                   carSpot[0].addioffset = new Vector3(-0.4f, 2.2f + 0.4f, 0f);
                   carSpot[1].addioffset = new Vector3(0.5f, 2.2f - 0.4f, 0.4f);
                   carSpot[2].addioffset = new Vector3(-0.5f, -1.2f + 0.15f, 0.45f);
                   carSpot[3].addioffset = new Vector3(0.5f, -1.2f, 0.8f);
                   break;
               case "AMBULAN":
                   carSpot[0].addioffset = new Vector3(0, -0.8f, 1.35f);
                   carSpot[1].addioffset = new Vector3(0, -0.8f, 1.35f);
                   carSpot[2].addioffset = new Vector3(0, 0.8f, 0.15f);
                   carSpot[3].addioffset = new Vector3(0, 0.8f, 0.15f);
                   break;
               case "NSTOCK": case "PSTOCK":
                   carSpot[0].addioffset = new Vector3(0, -0.8f, 1.75f);
                   carSpot[1].addioffset = new Vector3(0, -0.8f, 1.75f);
                   carSpot[2].addioffset = new Vector3(0, 0.8f, 0.75f);
                   carSpot[3].addioffset = new Vector3(0, 0.8f, 0.75f);
                   break;
               case "TRUSH":
                   carSpot[0].addioffset = new Vector3(0, -0.8f, 1.95f);
                   carSpot[1].addioffset = new Vector3(0, -0.8f, 1.95f);
                   carSpot[2].addioffset = new Vector3(0, 1.9f, 1.25f);
                   carSpot[3].addioffset = new Vector3(0, 1.9f, 1.25f);
                   break;
               case "YANKEE":
                   carSpot[0].addioffset = new Vector3(0, -1.7f, 2.15f);
                   carSpot[1].addioffset = new Vector3(0, -1.7f, 2.15f);
                   carSpot[2].addioffset = new Vector3(0, -0.34f, 1.25f);
                   carSpot[3].addioffset = new Vector3(0, -0.34f, 1.25f);
                   break;
               case "ANNHIL":
                   carSpot[0].addioffset = new Vector3(0.4f, -7.4f, 0.55f);
                   carSpot[1].addioffset = new Vector3(-0.4f, -7.4f, 0.55f);
                   carSpot[2].addioffset = new Vector3(0, 2.34f, 0.35f);
                   carSpot[3].addioffset = new Vector3(0, 2.34f, 0.35f);
                   break;
               case "FIRETRUK":
                   carSpot[0].addioffset = new Vector3(0, -0.8f, 0.75f);
                   carSpot[1].addioffset = new Vector3(0, -0.8f, 0.75f);
                   carSpot[2].addioffset = new Vector3(0, 0.8f, 0.95f);
                   carSpot[3].addioffset = new Vector3(0, 0.8f, 0.95f);
                   break;
               case "STOCK":
                   carSpot[0].addioffset = new Vector3(0, -0.8f, 1.8f);
                   carSpot[1].addioffset = new Vector3(0, -0.8f, 1.8f);
                   carSpot[2].addioffset = new Vector3(0, 0.8f, 0.85f);
                   carSpot[3].addioffset = new Vector3(0, 0.8f, 0.85f);
                   break;
               case "PACKER":
                   carSpot[0].addioffset = new Vector3(0, 4.48f, 1.35f);
                   carSpot[1].addioffset = new Vector3(0, 4.48f, 1.35f);
                   carSpot[2].addioffset = new Vector3(0, 1.78f, 1.35f);
                   carSpot[3].addioffset = new Vector3(0, 1.78f, 1.35f);
                   break;
               case "MULE":
                   carSpot[0].addioffset = new Vector3(0, -0.8f, 2f);
                   carSpot[1].addioffset = new Vector3(0, -0.8f, 2f);
                   carSpot[2].addioffset = new Vector3(0, 0.8f, 0.95f);
                   carSpot[3].addioffset = new Vector3(0, 0.8f, 0.95f);
                   break;
               case "PHANTOM":
                   carSpot[0].addioffset = new Vector3(0, 3.8f, 1.6f);
                   carSpot[1].addioffset = new Vector3(0, 3.8f, 1.6f);
                   carSpot[2].addioffset = new Vector3(0, 1.8f, 0.64f);
                   carSpot[3].addioffset = new Vector3(0, 1.8f, 0.64f);
                   break;
               case "NOOSE":
                   carSpot[2].addioffset = new Vector3(0, 0f, -0.25f);
                   carSpot[3].addioffset = new Vector3(0, 0f, -0.25f);
                   break;
               case "ORACLE":
                   carSpot[2].addioffset = new Vector3(0, 0f, -0.25f);
                   carSpot[3].addioffset = new Vector3(0, 0f, -0.25f);
                   break;
               case "BOXVLE":
                   carSpot[0].addioffset = new Vector3(0, -0.8f, 1.35f);
                   carSpot[1].addioffset = new Vector3(0, -0.8f, 1.35f);
                   carSpot[2].addioffset = new Vector3(0, 0.8f, -0.25f);
                   carSpot[3].addioffset = new Vector3(0, 0.8f, -0.25f);
                   break;
               case "BIFF":
                   carSpot[0].addioffset = new Vector3(-0.2f, 2.2f+1.8f, 1.15f);
                   carSpot[1].addioffset = new Vector3(0.2f, 2.2f + 1.8f, 1.15f);
                   carSpot[2].addioffset = new Vector3(0, 0.2f + 1.8f, 0.2f);
                   carSpot[3].addioffset = new Vector3(0, 0.2f + 1.8f, 0.2f);
                   break;
               case "BENSON":
                   carSpot[0].addioffset = new Vector3(0, -2.6f, 1.75f);
                   carSpot[1].addioffset = new Vector3(0, -2.6f, 1.75f);
                   carSpot[2].addioffset = new Vector3(0, 0.4f, 1.1f);
                   carSpot[3].addioffset = new Vector3(0, 0.4f, 1.1f);
                   break;
               case "CONTENDE":
                   carSpot[0].addioffset = new Vector3(0, 0f, 0.35f);
                   carSpot[1].addioffset = new Vector3(0, 0f, 0.35f);
                   carSpot[2].addioffset = new Vector3(0, 0f, 0.15f);
                   carSpot[3].addioffset = new Vector3(0, 0f, 0.15f);
                   break;
               case "RIPLEY":
                   carSpot[0].addioffset = new Vector3(0.2f, 0f, 0.35f);
                   carSpot[1].addioffset = new Vector3(-0.2f, 0f, 0.35f);
                   carSpot[2].addioffset = new Vector3(0.2f, 0f, 0.35f);
                   carSpot[3].addioffset = new Vector3(-0.2f, 0f, 0.35f);
                   break;
               case "PATRIOT": case "POLPAT":
                   carSpot[0].addioffset = new Vector3(0, 0.3f, 0.8f);
                   carSpot[1].addioffset = new Vector3(0, 0.3f, 0.8f);
                   carSpot[2].addioffset = new Vector3(0, 0.3f, 0.15f);
                   carSpot[3].addioffset = new Vector3(0, 0.3f, 0.15f);
                   break;
               case "FORK":
                   carSpot[0].addioffset = new Vector3(-0.2f, 1.8f, 1.26f);
                   carSpot[1].addioffset = new Vector3(0.2f, 1.8f, 1.26f);
                   carSpot[2].addioffset = new Vector3(-0.2f, 0.6f, -0.6f);
                   carSpot[3].addioffset = new Vector3(0.2f, 0.6f, -0.6f);
                   break;
               case "MOONB":
                   carSpot[0].addioffset = new Vector3(0, 0, 0.75f);
                   carSpot[1].addioffset = new Vector3(0, 0, 0.75f);
                   break;
               case "SOLAIR":
                   carSpot[0].addioffset = new Vector3(0, 0.4f, 0.55f);
                   carSpot[1].addioffset = new Vector3(0, 0.4f, 0.55f);
                   break;
               case "STRATUM":
                   carSpot[0].addioffset = new Vector3(0, 0.4f, 0.55f);
                   carSpot[1].addioffset = new Vector3(0, 0.4f, 0.55f);
                   break;
               case "PONY":
                   carSpot[0].addioffset = new Vector3(0, 0, 0.75f);
                   carSpot[1].addioffset = new Vector3(0, 0, 0.75f);
                   carSpot[2].addioffset = new Vector3(0, 0.4f, 0f);
                   carSpot[3].addioffset = new Vector3(0, 0.4f, 0f);
                   break;
               case "STEED":
                   carSpot[0].addioffset = new Vector3(0, -0.6f, 1.95f);
                   carSpot[1].addioffset = new Vector3(0, -0.6f, 1.95f);
                   carSpot[2].addioffset = new Vector3(0, -0.2f, 1.08f);
                   carSpot[3].addioffset = new Vector3(0, -0.2f, 1.08f);
                   break;
               case "LOKUS":
                   carSpot[0].addioffset = new Vector3(0, 0, 0.25f);
                   carSpot[1].addioffset = new Vector3(0, 0, 0.25f);
                   break;
               case "MERIT":
                   carSpot[2].addioffset = new Vector3(0, 0, -0.25f);
                   carSpot[3].addioffset = new Vector3(0, 0, -0.25f);
                   break;
               case "INGOT":
                   carSpot[0].addioffset = new Vector3(-0.2f, 0.4f, 0.25f);
                   carSpot[1].addioffset = new Vector3(0.2f, 0.4f, 0.25f);
                   carSpot[2].addioffset = new Vector3(0, 0, -0.25f);
                   carSpot[3].addioffset = new Vector3(0, 0, -0.25f);
                   break;
               case "HABANRO":
                   carSpot[0].addioffset = new Vector3(0, 0.6f, 0.4f);
                   carSpot[1].addioffset = new Vector3(0, 0.6f, 0.4f);
                   break;
               case "HUNT":
                   carSpot[0].addioffset = new Vector3(0, 0.7f, 0.6f);
                   carSpot[1].addioffset = new Vector3(0, 0.7f, 0.6f);
                   break;
               case "BANSHEE":
                   carSpot[2].addioffset = new Vector3(0, -0.4f, -0.15f);
                   carSpot[3].addioffset = new Vector3(0, -0.4f, -0.15f);
                   break;
               case "INFERNUS":
                   carSpot[0].addioffset = new Vector3(0, 0.4f, 0.05f);
                   carSpot[1].addioffset = new Vector3(0, 0.4f, 0.05f);
                   carSpot[2].addioffset = new Vector3(0, 0f, -0.35f);
                   carSpot[3].addioffset = new Vector3(0, 0f, -0.35f);
                   break;
               case "AIRTUG":
                   carSpot[0].addioffset = new Vector3(-0.5f, 3f, 0.15f);
                   carSpot[1].addioffset = new Vector3(0.5f, 2.5f, 0.25f);
                   carSpot[2].addioffset = new Vector3(0, -0.5f, -0.25f);
                   carSpot[3].addioffset = new Vector3(0, -0.5f, -0.25f);
                   break;
               case "REBLA":
                   carSpot[0].addioffset = new Vector3(0, 0.6f, 0.55f);
                   carSpot[1].addioffset = new Vector3(0, 0.6f, 0.55f);
                   break;
               case "LANSTALK":
                   carSpot[0].addioffset = new Vector3(-0.2f, 0, 0.95f);
                   carSpot[1].addioffset = new Vector3(0.2f, 0, 0.95f);
                   carSpot[2].addioffset = new Vector3(0, 0.2f, 0.3f);
                   carSpot[3].addioffset = new Vector3(0, 0.2f, 0.3f);
                   break;
               case "SPEEDO":
                   carSpot[0].addioffset = new Vector3(-0.2f, 0, 0.85f);
                   carSpot[1].addioffset = new Vector3(0.2f, 0, 0.85f);
                   carSpot[2].addioffset = new Vector3(0, 0.5f, -0.1f);
                   carSpot[3].addioffset = new Vector3(0, 0.5f, -0.1f);
                   break;
               case "RANCHER":
                   carSpot[0].addioffset = new Vector3(-0.2f, 2.2f, 0.75f);
                   carSpot[1].addioffset = new Vector3(0.2f, 2.2f, 0.75f);
                   carSpot[2].addioffset = new Vector3(0, 0.2f, 0.2f);
                   carSpot[3].addioffset = new Vector3(0, 0.2f, 0.2f);
                   break;
               case "MINVAN":
                   carSpot[0].addioffset = new Vector3(-0.2f, 2.2f, 0.55f);
                   carSpot[1].addioffset = new Vector3(0.2f, 2.2f, 0.55f);
                   carSpot[2].addioffset = new Vector3(0, 0.2f, -0.2f);
                   carSpot[3].addioffset = new Vector3(0, 0.2f, -0.2f);
                   break;
               case "CAVCADE":
                   carSpot[0].addioffset = new Vector3(-0.2f, 2.2f, 0.55f);
                   carSpot[1].addioffset = new Vector3(0.2f, 2.2f, 0.55f);
                   break;
               case "CABBY":
                   carSpot[0].addioffset = new Vector3(-0.2f, 2.2f, 0.55f);
                   carSpot[1].addioffset = new Vector3(0.2f, 2.2f, 0.55f);
                   carSpot[2].addioffset = new Vector3(0, 0.2f, -0.2f);
                   carSpot[3].addioffset = new Vector3(0, 0.2f, -0.2f);
                   break;
               case "PEREN": case "PEREN2":
                   carSpot[0].addioffset = new Vector3(-0.2f, 0, 0.65f);
                   carSpot[1].addioffset = new Vector3(0.2f, 0, 0.65f);
                   carSpot[2].addioffset = new Vector3(0, 0.2f, 0.1f);
                   carSpot[3].addioffset = new Vector3(0, 0.2f, 0.1f);
                   break;
               case "CHAV":
                   carSpot[0].addioffset = new Vector3(0, 0.3f, 0.1f);
                   carSpot[1].addioffset = new Vector3(0, 0.3f, 0.1f);
                   break;
               case "BUCCNEER":
                   carSpot[0].addioffset = new Vector3(0, 0f, -0.3f);
                   carSpot[1].addioffset = new Vector3(0, 0f, -0.3f);
                   carSpot[2].addioffset = new Vector3(0, 0f, -0.3f);
                   carSpot[3].addioffset = new Vector3(0, 0f, -0.3f);
                   break;
               case "BUS":
                   carSpot[0].addioffset = new Vector3(0, -1.75f, -0.3f);
                   carSpot[1].addioffset = new Vector3(0, -1.75f, -0.3f);
                   carSpot[2].addioffset = new Vector3(0, -1.75f, -0.3f);
                   carSpot[3].addioffset = new Vector3(0, -1.75f, -0.3f);
                   break;
               case "MRTASTY":
                   carSpot[0].addioffset = new Vector3(0, -0.6f, 1.45f);
                   carSpot[1].addioffset = new Vector3(0, -0.6f, 1.45f);
                   carSpot[2].addioffset = new Vector3(0, -0.2f, 1.45f);
                   carSpot[3].addioffset = new Vector3(0, -0.2f, 1.45f);
                   break;
               case "SENTINEL":
                   carSpot[0].addioffset = new Vector3(0, 0.3f, -0.1f);
                   carSpot[1].addioffset = new Vector3(0, 0.3f, -0.1f);
                   carSpot[2].addioffset = new Vector3(0, 0, -0.25f);
                   carSpot[3].addioffset = new Vector3(0, 0, -0.25f);
                   break;
               case "SUPER":
                   carSpot[0].addioffset = new Vector3(0, 0.3f, -0.1f);
                   carSpot[1].addioffset = new Vector3(0, 0.3f, -0.1f);
                   carSpot[2].addioffset = new Vector3(0, 0, -0.25f);
                   carSpot[3].addioffset = new Vector3(0, 0, -0.25f);
                   break;
               case "RUINER":
                   carSpot[0].addioffset = new Vector3(0, 0.3f, -0.1f);
                   carSpot[1].addioffset = new Vector3(0, 0.3f, -0.1f);
                   carSpot[2].addioffset = new Vector3(0, 0, -0.25f);
                   carSpot[3].addioffset = new Vector3(0, 0, -0.25f);
                   break;
               case "COQUETTE":
                   carSpot[0].addioffset = new Vector3(0, 0.3f, -0.1f);
                   carSpot[1].addioffset = new Vector3(0, 0.3f, -0.1f);
                   carSpot[2].addioffset = new Vector3(0, 0, -0.25f);
                   carSpot[3].addioffset = new Vector3(0, 0, -0.25f);
                   break;
               case "FELTZER":
                   carSpot[0].addioffset = new Vector3(0, 0.3f, -0.1f);
                   carSpot[1].addioffset = new Vector3(0, 0.3f, -0.1f);
                   carSpot[2].addioffset = new Vector3(0, 0, -0.25f);
                   carSpot[3].addioffset = new Vector3(0, 0, -0.25f);
                   break;
               case "COMET":
                   carSpot[0].addioffset = new Vector3(0, 0.3f, -0.1f);
                   carSpot[1].addioffset = new Vector3(0, 0.3f, -0.1f);
                   carSpot[2].addioffset = new Vector3(0, 0, -0.25f);
                   carSpot[3].addioffset = new Vector3(0, 0, -0.25f);
                   break;
               case "DILANTE":
                   carSpot[0].addioffset = new Vector3(0, 0.4f, 0.4f);
                   carSpot[1].addioffset = new Vector3(0, 0.4f, 0.4f);
                   carSpot[2].addioffset = new Vector3(0, 0.4f, -0.25f);
                   carSpot[3].addioffset = new Vector3(0, 0.4f, -0.25f);
                   break;
               case "FEROCI": case "FEROCI2":
                   carSpot[0].addioffset = new Vector3(0, 0f, 0.3f);
                   carSpot[1].addioffset = new Vector3(0, 0f, 0.3f);
                   break;
               case "TURISMO":
                   carSpot[0].addioffset = new Vector3(0, 0.5f, -0.1f);
                   carSpot[1].addioffset = new Vector3(0, 0.5f, -0.1f);
                   carSpot[2].addioffset = new Vector3(0, 0, -0.25f);
                   carSpot[3].addioffset = new Vector3(0, 0, -0.25f);
                   break;
               case "STRETCH":
                   carSpot[0].addioffset = new Vector3(-0.15f, 0, 0.25f);
                   carSpot[1].addioffset = new Vector3(0.15f, 0, 0.25f);
                   carSpot[2].addioffset = new Vector3(-0.15f, -0.4f, 0.25f);
                   carSpot[3].addioffset = new Vector3(0.15f, -0.4f, 0.25f);
                   break;
           }
       }

       private void CarBodyguard_Tick(object sender, EventArgs e)
      {
          // Is the current vehicle being tracked? Has the player exited the vehicle?
          if (curVeh == null || Player.Character.CurrentVehicle == null)
          {
              speedChange = 0f;
              oldSpeed = 0f;

              // Detach every ped
              for (int i = 0; i < 4; i++)
              {
                  if (carSpot[i].ped != null)
                  {
                      detachPedSpot(carSpot[i]);
                  }
              }
          }

          for (int i = 0; i < 4; i++)
          {
              // Update each spot
              SpotTick(carSpot[i]);
          }

          if (actionWait > 0) { actionWait--; }
          if (actionWait2 > 0) { actionWait2--; }

          if (Player.Character.CurrentVehicle != null)
          {
              speedChange = Player.Character.CurrentVehicle.Speed - oldSpeed;
              oldSpeed = Player.Character.CurrentVehicle.Speed;

              if (Player.Character.CurrentVehicle.isOnAllWheels & oldSpeed < 12)
              {
                  if (!Player.Character.CurrentVehicle.isSeatFree(VehicleSeat.AnyPassengerSeat) & Player.Character.CurrentVehicle.Exists() & Player.Character.isInVehicle() & !Player.Character.isGettingIntoAVehicle)
                  {
                      CarPassenger pspot = null;
                      foreach (CarPassenger tspot in carSpot)
                      {
                          if (tspot.ped == null)
                          {
                              pspot = tspot;
                              break;
                          }
                      }

                      if (pspot != null)
                      {
                          if (group.MemberCount > 0 & pspot.ped == null)
                          {
                              curVeh = Player.Character.CurrentVehicle;

                              for (int k = 0; k < group.MaxMemberCount; k++)
                              {
                                  Ped tmpCar = group.GetMember(k);
                                  if (tmpCar != null)
                                  {
                                      bool alreadyIn = false;
                                      foreach (CarPassenger cptmp in carSpot)
                                      {
                                          if (cptmp.ped == tmpCar)
                                          {
                                              alreadyIn = true;
                                              break;
                                          }
                                      }

                                      if (!alreadyIn)
                                      {
                                          if (tmpCar.isAliveAndWell & !tmpCar.isGettingIntoAVehicle & !tmpCar.isInVehicle() & tmpCar.Exists())
                                          {
                                              if (!tmpCar.isRagdoll & !tmpCar.isGettingUp)
                                              {
                                                  pspot.ped = tmpCar; break;
                                              }
                                          }
                                      }
                                  }
                              }

                              if (pspot.ped != null)
                              {
                                  GTA.Native.Pointer ModelPointer = typeof(Model);
                                  if (ModelPointer != null)
                                  {
                                      GTA.Native.Function.Call("GET_CAR_MODEL", curVeh, ModelPointer);

                                      String name = GTA.Native.Function.Call<String>("GET_DISPLAY_NAME_FROM_VEHICLE_MODEL", ModelPointer.ToInputParameter());
                                      if (name != null)
                                      {
                                          Game.DisplayText("Car name: " + name);
                                          setAddiOffset(name);
                                      }
                                  }
                                  pspot.ped.Task.ClearAll();
                                  pspot.ped.Task.RunTo(pspot.offset + pspot.addioffset + curVeh.Position);
                                  pspot.sitting = false;
                                  pspot.combat = false;
                                  pspot.vehicle = curVeh;
                              }
                          }
                      }
                  }
              }
          }
      }


      private void AddToGroup(Ped p)
      {
          if (!Exists(p)) return; // check if the ped is valid

          p.CurrentRoom = Player.Character.CurrentRoom; // required, or ped won't be visible when spawned inside a building
          p.WillDoDrivebys = true;
          p.PriorityTargetForEnemies = true;
          p.DuckWhenAimedAtByGroupMember = false;
          p.AlwaysDiesOnLowHealth = true;
          p.SetPathfinding(true, true, true);

          Weapon weap = Player.Character.Weapons.CurrentType;
          p.Weapons.FromType(weap).Ammo = 30000;
          p.Weapons.MP5.Ammo = 30000;
          p.Weapons.Select(weap); // activate same weapon as the one the player carries

          p.RelationshipGroup = RelationshipGroup.Player;
          p.ChangeRelationship(RelationshipGroup.Player, Relationship.Companion);
          p.CantBeDamagedByRelationshipGroup(RelationshipGroup.Player, true);

          group.AddMember(p);
          Game.DisplayText(group.MemberCount + " members in gang");
      }

      private void CarBodyguard_KeyDown(object sender, GTA.KeyEventArgs e) 
      {

          switch (e.Key)
          {

              case Keys.Insert:
                  if (group.MemberCount < 7)
                  { 
                      // limit to 8 members, to make sure that all fit in a car
                      Ped p = World.CreatePed(PedModel, Player.Character.Position.Around(3.0F), RelationshipGroup.Player);
                      AddToGroup(p);
                  }
                  break;

              case Keys.Delete:
                  foreach (Ped member in group)
                  {
                      member.Weapons.RemoveAll();
                      member.Die();
                  }
                  group.RemoveAllMembers();
                  break;
          }
        
      }

   }
}
