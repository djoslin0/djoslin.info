﻿using System;
using System.Drawing;
using System.Windows.Forms;
using GTA;
using System.Collections;

namespace TestScriptCS
{

    //### Press J to enable powers
    public class ObjectStorm : Script
    {
        bool isUsingPower = false;
        int mtimeout = 0;

        GTA.Object[] objs;
        GTA.Ped[] mpeds;
        ArrayList objball;
        ArrayList pedTargets;
        Ped pTarget;

        public ObjectStorm()
        {
            Interval = 1;
            objball = new ArrayList();
            pedTargets = new ArrayList();

            this.KeyDown += new GTA.KeyEventHandler(this.ObjectStorm_KeyDown);
            this.Tick += new EventHandler(this.ObjectStorm_Tick);
        }

        private void ObjectStorm_KeyDown(object sender, GTA.KeyEventArgs e)
        {
            if (e.Key != Keys.J) return;
            isUsingPower = !isUsingPower;

            if (isUsingPower)
            {
                Game.DisplayText("Object Storm: ON");
            }
            else
            {
                Game.DisplayText("Object Storm: OFF");
            }

        }


        private void ObjectStorm_Tick(object sender, EventArgs e)
        {
            if (!isUsingPower) { return; }

            // Update target info
            if (pTarget == null) { pTarget = Player.GetTargetedPed(); }
            if (!Exists(pTarget)) { pTarget = Player.GetTargetedPed(); } else { if (!pTarget.isAliveAndWell) { pTarget = Player.GetTargetedPed(); } }
            if (Player.GetTargetedPed() != null) { pTarget = Player.GetTargetedPed(); }

            mtimeout++;

            Vector3 charposview = Player.Character.Position + (new Vector3(0, 0, 2f));
            if (pTarget != null)
            {
                //  default object target position
                if (pTarget.Exists()) { charposview = pTarget.Position; }
            }

            if (mtimeout > 100)
            {
                // every 100 ticks, scan the world for objects

                mtimeout = 0;
                objs = World.GetAllObjects();

                bool cont = true;
                while (cont)
                {
                    cont = false;
                    foreach (GTA.Object tobj in objball)
                    {
                        if (tobj.Exists())
                        {
                            if (tobj.Position.DistanceTo(charposview) >= 128f)
                            {
                                // remove far away objects
                                objball.Remove(tobj);
                                cont = true; break;
                            }
                        }
                        else
                        {
                            // remove objects that don't exist
                            objball.Remove(tobj);
                            cont = true; break;
                        }
                    }
                }

                foreach (GTA.Object tobj in objs)
                {
                    if (tobj.Exists())
                    {
                        if (tobj.Position.DistanceTo(Player.Character.Position) < 12f)
                        {
                            // if the object is nearby, add it to the list
                            //tobj.Detach();
                            GTA.Native.Function.Call("DONT_REMOVE_OBJECT", tobj, true);
                            if (objball.Contains(tobj) == false) { objball.Add(tobj); }
                            /*GTA.Native.Function.Call("SET_OBJECT_AS_STEALABLE", tobj, true);
                            GTA.Native.Function.Call("DETACH_OBJECT", tobj, true);
                            GTA.Native.Function.Call("ANCHOR_OBJECT", tobj, false, 1.0f);
                            GTA.Native.Function.Call("SET_OBJECT_DYNAMIC", tobj, true);
                            GTA.Native.Function.Call("SET_OBJECT_COLLISION", tobj, true);
                            GTA.Native.Function.Call("DONT_REMOVE_OBJECT", tobj, true);
                            GTA.Native.Function.Call("FREEZE_OBJECT_POSITION", tobj, false);
                            GTA.Native.Function.Call("SET_ACTIVATE_OBJECT_PHYSICS_AS_SOON_AS_IT_IS_UNFROZEN", tobj, true);*/
                        }
                    }
                }


                Game.DisplayText("Object Storm: " + objball.Count);
            }


            if (objs == null) { return; }
            int maxx = 0;
            foreach (GTA.Object tobj in objball)
            {
                if (tobj.Exists())
                {
                    maxx++;
                    Vector3 nvec = new Vector3(tobj.Position.X - charposview.X, tobj.Position.Y - charposview.Y, tobj.Position.Z - charposview.Z - 1.5f);
                    if (pTarget != null)
                    {
                        if (pTarget.Exists())
                        {
                            if (pTarget.isInVehicle()) { nvec.Z = nvec.Z + 2f; }
                        }
                    }

                    nvec.Normalize();
                    nvec /= 1f;

                    if (tobj.Position.DistanceTo(Player.Character.Position) < 6f)
                    {
                        // This object is too close, rebound away from player
                        if (tobj.Exists()) { tobj.Velocity *= 0.9f; }
                        Vector3 nvec2 = new Vector3(tobj.Position.X - Player.Character.Position.X, tobj.Position.Y - Player.Character.Position.Y, tobj.Position.Z - Player.Character.Position.Z);

                        nvec2.Normalize();
                        nvec2 /= 4;
                        if (tobj.Exists()) { tobj.Velocity += nvec2; }
                    }

                    if (pTarget == null & tobj.Position.DistanceTo(charposview) < 6f)
                    {
                        if (tobj.Exists()) { tobj.Velocity += nvec * 0.1f; }
                    }
                    else
                    {
                        if (tobj.Exists()) 
                        { 
                            tobj.Velocity -= nvec * 0.75f;
                            if (pTarget == null) { tobj.Velocity = tobj.Velocity * 0.9f; }
                        }
                    }
                }

            }
        }
    }
}